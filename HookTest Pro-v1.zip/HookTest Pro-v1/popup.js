document.addEventListener('DOMContentLoaded', function () {
    const methodSelect = document.getElementById('method');
    const getFields = document.getElementById('get-fields');
    const postFields = document.getElementById('post-fields');
    const addGetParamBtn = document.getElementById('add-get-param');
    const getParamsContainer = document.getElementById('get-params');
    const errorMessageDiv = document.getElementById('error-message');
    const errorText = document.getElementById('error-text');
    const responseMessageDiv = document.getElementById('response-message');
    const responseText = document.getElementById('response-text');
    let paramCounter = 1;
  
    // On load, ensure GET fields are visible (default is GET)
    if (methodSelect.value === 'GET') {
      getFields.classList.remove('hidden');
      postFields.classList.add('hidden');
    }
  
    // Switch between GET and POST fields based on selected method
    methodSelect.addEventListener('change', function () {
      if (methodSelect.value === 'GET') {
        getFields.classList.remove('hidden');
        postFields.classList.add('hidden');
      } else {
        getFields.classList.add('hidden');
        postFields.classList.remove('hidden');
      }
    });
  
    // Add new GET parameter fields
    addGetParamBtn.addEventListener('click', function () {
      paramCounter++;
      const paramDiv = document.createElement('div');
      paramDiv.classList.add('flex', 'space-x-2', 'mb-2', 'get-param-row');
      paramDiv.innerHTML = `
        <input type="text" placeholder="Key" class="w-1/3 p-2 border border-gray-300 rounded" id="key${paramCounter}">
        <input type="text" placeholder="Value" class="w-1/3 p-2 border border-gray-300 rounded" id="value${paramCounter}">
        <button class="remove-param text-red-500 font-bold">❌</button>
      `;
      getParamsContainer.appendChild(paramDiv);
  
      // Add remove functionality to the new row
      paramDiv.querySelector('.remove-param').addEventListener('click', function () {
        paramDiv.remove();
      });
    });
  
    // Handle remove buttons for initial parameter row
    document.querySelectorAll('.remove-param').forEach(button => {
      button.addEventListener('click', function (event) {
        event.target.parentElement.remove();
      });
    });
  
    // Utility function to show error messages
    function showError(message) {
      errorText.textContent = message;
      errorMessageDiv.classList.remove('hidden');
    }
  
    // Utility function to hide error messages
    function hideError() {
      errorMessageDiv.classList.add('hidden');
    }
  
    // Utility function to show webhook response
    function showResponse(message) {
      responseText.innerHTML = message; // Changed to innerHTML for formatted display
      responseMessageDiv.classList.remove('hidden');
    }
  
    // Utility function to hide webhook response
    function hideResponse() {
      responseMessageDiv.classList.add('hidden');
    }
  
    // Function to format JSON response or error
    function formatJSON(json) {
      const formatted = JSON.stringify(json, null, 2) // Format JSON with 2 spaces for indentation
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
      return `<pre>${formatted}</pre>`;
    }
  
    // Send the request
    document.getElementById('send-request').addEventListener('click', function () {
      const url = document.getElementById('url').value;
      const method = methodSelect.value;
  
      // Validate URL
      if (!url) {
        showError("Please enter a valid webhook URL.");
        return;
      }
  
      // Clear any previous error and response messages
      hideError();
      hideResponse();
  
      if (method === 'GET') {
        const params = new URLSearchParams();
        document.querySelectorAll('.get-param-row').forEach((row, index) => {
          const key = row.querySelector(`input[id^="key"]`).value;
          const value = row.querySelector(`input[id^="value"]`).value;
          if (key && value) {
            params.append(key, value);
          }
        });
  
        fetch(`${url}?${params.toString()}`, {
          method: 'GET'
        })
        .then(response => {
          if (!response.ok) {
            throw new Error(`GET request failed with status: ${response.status}`);
          }
          return response.json(); // Parse JSON response
        })
        .then(data => showResponse(`Response: ${formatJSON(data)}`)) // Format and show response
        .catch(error => {
          try {
            const errorData = JSON.parse(error.message); // Attempt to parse error message as JSON
            showError(`Error: ${formatJSON(errorData)}`); // Format and show error
          } catch {
            showError(`Error: ${error.message}`);
          }
        });
  
      } else if (method === 'POST') {
        const body = document.getElementById('post-body').value;
  
        // Validate POST body
        try {
          JSON.parse(body); // This checks if the body is valid JSON
        } catch (error) {
          showError("Invalid JSON format in POST body.");
          return;
        }
  
        fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: body
        })
        .then(response => {
          if (!response.ok) {
            throw new Error(`POST request failed with status: ${response.status}`);
          }
          return response.json(); // Parse JSON response
        })
        .then(data => showResponse(`Response: ${formatJSON(data)}`)) // Format and show response
        .catch(error => {
          try {
            const errorData = JSON.parse(error.message); // Attempt to parse error message as JSON
            showError(`Error: ${formatJSON(errorData)}`); // Format and show error
          } catch {
            showError(`Error: ${error.message}`);
          }
        });
      }
    });
  });
  